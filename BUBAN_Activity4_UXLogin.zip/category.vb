﻿Public Class category
    Private Sub category_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class