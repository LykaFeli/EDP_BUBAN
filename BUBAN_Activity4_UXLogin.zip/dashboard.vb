﻿Public Class dashboard
    Private Sub Guna2Button5_Click(sender As Object, e As EventArgs) Handles Guna2Button5.Click
        usermngmnt.Show() ' Show the user management form
    End Sub

    Private Sub Guna2Button6_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Guna2Button2_Click(sender As Object, e As EventArgs) Handles Guna2Button2.Click
        Dim productMgmtForm As New Productmanagement()
        productMgmtForm.Show()
    End Sub

    Private Sub Guna2Button3_Click(sender As Object, e As EventArgs) Handles Guna2Button3.Click
        Dim orderMgmtForm As New order_details()
        orderMgmtForm.Show()
    End Sub

    Private Sub Guna2Button4_Click(sender As Object, e As EventArgs) Handles Guna2Button4.Click
        Dim categoryForm As New category()
        categoryForm.Show()
    End Sub

End Class
